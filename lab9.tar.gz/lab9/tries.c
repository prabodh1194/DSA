void insert(node *root, char *word)
{
	
}